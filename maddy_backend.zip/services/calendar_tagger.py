"""
Calendar auto-tag engine (Step 2).
Processes calendar_events rows for a user + date range and writes
matching tags to user_daily_tags.
"""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any

from db import get_db

TRAVEL_KEYWORDS = re.compile(
    r"\b(flight|hotel|airport|airbnb|train|amtrak|uber|lyft|depart|arrive|terminal)\b",
    re.IGNORECASE,
)
DOCTOR_KEYWORDS = re.compile(
    r"\b(doctor|ob/gyn|ob-gyn|clinic|therapy|therapist|appointment|dr\.)\b",
    re.IGNORECASE,
)
SICK_KEYWORDS = re.compile(
    r"\b(sick|rest day|recovery|migraine|unwell)\b",
    re.IGNORECASE,
)
SOCIAL_KEYWORDS = re.compile(
    r"\b(dinner|drinks|happy hour|party|brunch|lunch|birthday|celebration|game night|hangout)\b",
    re.IGNORECASE,
)
WORK_KEYWORDS = re.compile(
    r"\b(standup|sync|review|meeting|1:1|one.on.one|planning|retro|demo|kickoff|sprint|interview|presentation|all.hands|onboarding)\b",
    re.IGNORECASE,
)
OOO_KEYWORDS = re.compile(r"\b(ooo|out of office|vacation|holiday|pto)\b", re.IGNORECASE)


def _parse_dt(val: str | None) -> datetime | None:
    if not val:
        return None
    try:
        return datetime.fromisoformat(val.replace("Z", "+00:00"))
    except ValueError:
        return None


def _to_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _minutes_gap(end: datetime, start: datetime) -> float:
    return (start - end).total_seconds() / 60


def _event_start_dt(e: dict) -> datetime | None:
    """Return a datetime for the event start, handling both timed and all-day events."""
    dt = _parse_dt(e.get("start_dt"))
    if dt:
        return dt
    # All-day event: use start_date at midnight UTC
    d = e.get("start_date")
    if d:
        try:
            return datetime.fromisoformat(d).replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


def _event_end_dt(e: dict) -> datetime | None:
    dt = _parse_dt(e.get("end_dt"))
    if dt:
        return dt
    d = e.get("end_date")
    if d:
        try:
            return datetime.fromisoformat(d).replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


def evaluate_rules(events: list[dict[str, Any]], target_date: date) -> set[str]:
    """
    Apply all tagging rules to a list of calendar events for target_date.
    Returns a set of tag *names* that fired.
    """
    fired: set[str] = set()
    day_events = [
        e for e in events
        if _event_start_dt(e) is not None
        and _event_start_dt(e).date() == target_date
    ]

    if not day_events:
        fired.add("rest_day_scheduled")
        return fired

    day_events.sort(key=lambda e: _event_start_dt(e))
    weekday = target_date.weekday()  # 0=Mon … 6=Sun
    is_weekend = weekday >= 5

    total_blocked_minutes = 0
    prev_end: datetime | None = None
    b2b_count = 0

    for ev in day_events:
        start_dt = _to_utc(_event_start_dt(ev))
        end_dt_raw = _event_end_dt(ev)
        end_dt = _to_utc(end_dt_raw) if end_dt_raw else None
        title: str = ev.get("summary") or ev.get("title") or ""
        attendees: list = ev.get("attendees") or []
        num_attendees = len(attendees) if isinstance(attendees, list) else 0

        if end_dt:
            duration_min = (end_dt - start_dt).total_seconds() / 60
            total_blocked_minutes += max(0, duration_min)

        # working_late — event ends after 20:00 on weekday
        if not is_weekend and end_dt and end_dt.hour >= 20:
            fired.add("working_late")

        # early_morning — starts before 07:00
        if start_dt.hour < 7:
            fired.add("early_morning")

        # late_night — ends after 22:30
        if end_dt and (end_dt.hour > 22 or (end_dt.hour == 22 and end_dt.minute >= 30)):
            fired.add("late_night")

        # travel detection
        is_travel = bool(
            TRAVEL_KEYWORDS.search(title)
            or (ev.get("location") and any(
                city in (ev.get("location") or "")
                for city in ["NYC", "New York", "Seattle", "Chicago", "Austin", "Boston", "LA", "London"]
            ))
        )
        if is_travel:
            fired.add("traveling")
            if start_dt.hour < 6:
                fired.add("early_flight")
            # red-eye: event spans midnight (start and end on different days)
            if end_dt and end_dt.date() > start_dt.date():
                fired.add("red_eye")

        # doctor_appointment
        if DOCTOR_KEYWORDS.search(title):
            fired.add("doctor_appointment")

        # sick_day
        if SICK_KEYWORDS.search(title):
            fired.add("sick_day")

        # OOO / vacation (single-day contribution — multi-day checked below)
        if OOO_KEYWORDS.search(title):
            fired.add("vacation")

        # weekend_work — work-type event on weekend
        if is_weekend and WORK_KEYWORDS.search(title):
            fired.add("weekend_work")

        # social_event — evening, 2+ attendees, social keywords
        if (
            start_dt.hour >= 17
            and num_attendees >= 2
            and SOCIAL_KEYWORDS.search(title)
        ):
            fired.add("social_event")

        # back_to_back_meetings — running gap counter
        if prev_end is not None and end_dt:
            gap = _minutes_gap(prev_end, start_dt)
            if 0 <= gap < 15:
                b2b_count += 1
        if end_dt:
            prev_end = end_dt

    if b2b_count >= 2:  # 3+ events with <15 min gaps = 2+ consecutive tight pairs
        fired.add("back_to_back_meetings")

    if total_blocked_minutes > 600:  # >10 hours
        fired.add("long_workday")

    return fired


def _get_tag_id_map(db) -> dict[str, str]:
    rows = db.table("tags").select("id, name").execute().data
    return {r["name"]: r["id"] for r in rows}


def run_auto_tagger(user_id: str, start: date, end: date) -> dict[str, list[str]]:
    """
    Fetch calendar events for [start, end], apply rules day by day,
    write results to user_daily_tags (upsert), and return a summary.
    """
    db = get_db()
    tag_id_map = _get_tag_id_map(db)

    events_resp = (
        db.table("calendar_events")
        .select("*")
        .gte("start_dt", start.isoformat())
        .lte("start_dt", (end + timedelta(days=1)).isoformat())
        .execute()
    )
    events = events_resp.data or []

    # Also pull all-day events by start_date for the same window
    allday_resp = (
        db.table("calendar_events")
        .select("*")
        .eq("all_day", True)
        .gte("start_date", start.isoformat())
        .lte("start_date", (end + timedelta(days=1)).isoformat())
        .execute()
    )
    events = events + (allday_resp.data or [])

    # Also check previous day for travel_recovery
    prev_day_events_resp = (
        db.table("calendar_events")
        .select("*")
        .gte("start_dt", (start - timedelta(days=1)).isoformat())
        .lt("start_dt", start.isoformat())
        .execute()
    )
    prev_events = prev_day_events_resp.data or []

    results: dict[str, list[str]] = {}
    current = start
    prev_day_fired: set[str] = evaluate_rules(prev_events, start - timedelta(days=1))

    while current <= end:
        fired = evaluate_rules(events, current)

        # travel_recovery — day after a traveling tag fired
        if "traveling" in prev_day_fired:
            fired.add("travel_recovery")

        results[current.isoformat()] = sorted(fired)

        # Write to user_daily_tags
        rows = []
        for tag_name in fired:
            if tag_name not in tag_id_map:
                continue
            rows.append({
                "user_id": user_id,
                "date": current.isoformat(),
                "tag_id": tag_id_map[tag_name],
                "source": "calendar",
            })

        if rows:
            db.table("user_daily_tags").upsert(rows, on_conflict="user_id,date,tag_id").execute()

        prev_day_fired = fired
        current += timedelta(days=1)

    return results


def run_computed_tags(user_id: str, anchor_date: date) -> list[str]:
    """
    Step 4: evaluate computed tags for a given anchor_date and the 7 days prior.
    Writes computed results to user_daily_tags.
    """
    db = get_db()
    tag_id_map = _get_tag_id_map(db)
    window_start = anchor_date - timedelta(days=6)

    rows_resp = (
        db.table("user_daily_tags")
        .select("date, tags(name)")
        .eq("user_id", user_id)
        .gte("date", window_start.isoformat())
        .lte("date", anchor_date.isoformat())
        .execute()
    )

    tag_names_in_window: list[str] = []
    by_date: dict[str, list[str]] = defaultdict(list)
    for row in rows_resp.data or []:
        tag_name = row.get("tags", {}).get("name") if isinstance(row.get("tags"), dict) else None
        if tag_name:
            tag_names_in_window.append(tag_name)
            by_date[row["date"]].append(tag_name)

    HIGH_STRESS_TAGS = {
        "working_late", "back_to_back_meetings", "long_workday",
        "weekend_work", "late_night", "anxious", "irritable", "low_energy",
    }
    high_stress_count = sum(1 for t in tag_names_in_window if t in HIGH_STRESS_TAGS)

    fired_computed: list[str] = []

    if high_stress_count >= 3:
        fired_computed.append("high_stress_week")

    # disrupted_schedule: travel + late_night + any of (b2b, early_morning, poor_sleep, jet_lagged)
    # within a 48-hour window around anchor_date
    two_day_tags: set[str] = set()
    for d, names in by_date.items():
        d_date = date.fromisoformat(d)
        if abs((d_date - anchor_date).days) <= 1:
            two_day_tags.update(names)

    disruption_trigger = {"traveling", "long_haul_travel"}
    disruption_support = {"back_to_back_meetings", "early_morning", "poor_sleep", "jet_lagged"}
    if (
        two_day_tags & disruption_trigger
        and "late_night" in two_day_tags
        and two_day_tags & disruption_support
    ):
        fired_computed.append("disrupted_schedule")

    if fired_computed:
        rows = [
            {
                "user_id": user_id,
                "date": anchor_date.isoformat(),
                "tag_id": tag_id_map[t],
                "source": "computed",
            }
            for t in fired_computed
            if t in tag_id_map
        ]
        if rows:
            db.table("user_daily_tags").upsert(rows, on_conflict="user_id,date,tag_id").execute()

    return fired_computed

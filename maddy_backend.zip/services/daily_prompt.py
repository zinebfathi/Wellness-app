"""
Daily prompt service (Step 8).
Returns which tag categories to show in the popup, with onboarding stub.
"""

from __future__ import annotations

from datetime import date

from db import get_db

PRIORITY_TO_CATEGORY_MAP: dict[str, list[str]] = {
    "performance":    ["workout_feeling", "energy_mood"],
    "cycle_health":   ["cycle_symptoms", "energy_mood"],
    "stress_balance": ["energy_mood", "sleep_quality"],
    "travel_fitness": ["travel_disruption", "workout_feeling"],
    "nutrition":      ["nutrition_lifestyle", "energy_mood"],
}


def get_daily_prompt_categories(user_id: str, today: date) -> list[str]:
    """
    Returns up to 3 tag categories for the daily popup.
    Uses context-aware defaults (stub) until onboarding priorities are wired in.
    """
    db = get_db()

    # Fetch today's auto-tags
    tags_resp = (
        db.table("user_daily_tags")
        .select("tags(name)")
        .eq("user_id", user_id)
        .eq("date", today.isoformat())
        .eq("source", "calendar")
        .execute()
    )
    today_tags: set[str] = set()
    for row in tags_resp.data or []:
        name = row.get("tags", {}).get("name") if isinstance(row.get("tags"), dict) else None
        if name:
            today_tags.add(name)

    # Fetch cycle phase from wearable summary
    wearable_resp = (
        db.table("wearable_daily_summary")
        .select("cycle_phase")
        .eq("user_id", user_id)
        .eq("date", today.isoformat())
        .limit(1)
        .execute()
    )
    cycle_phase: str | None = None
    if wearable_resp.data:
        cycle_phase = wearable_resp.data[0].get("cycle_phase")

    # Stub: context-aware defaults
    # TODO: replace with user_onboarding_priorities query when onboarding ships
    categories: list[str] = ["energy_mood", "workout_feeling"]

    if today_tags & {"traveling", "jet_lagged", "travel_recovery"}:
        categories.append("travel_disruption")
    elif cycle_phase in ("luteal", "menstrual"):
        categories.append("cycle_symptoms")
    else:
        categories.append("sleep_quality")

    return categories[:3]


def has_dismissed_today(user_id: str, today: date) -> bool:
    db = get_db()
    resp = (
        db.table("daily_prompt_dismissals")
        .select("id")
        .eq("user_id", user_id)
        .eq("date", today.isoformat())
        .limit(1)
        .execute()
    )
    return bool(resp.data)


def dismiss_today(user_id: str, today: date) -> None:
    db = get_db()
    db.table("daily_prompt_dismissals").upsert(
        {"user_id": user_id, "date": today.isoformat()},
        on_conflict="user_id,date",
    ).execute()

"""
Insights engine (Step 6).
For a user + date, evaluates insight_templates trigger conditions against
wearable_daily_summary and user_daily_tags (last 7 days), renders messages,
deduplicates against last 3 days of user_insights, and writes results.
"""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import date, timedelta
from typing import Any

from db import get_db

_VAR_RE = re.compile(r"\{\{(\w+)\}\}")


def _eval_numeric_condition(value: float | None, cond: dict) -> bool:
    if value is None:
        return False
    if "lt" in cond and not (value < cond["lt"]):
        return False
    if "lte" in cond and not (value <= cond["lte"]):
        return False
    if "gt" in cond and not (value > cond["gt"]):
        return False
    if "gte" in cond and not (value >= cond["gte"]):
        return False
    return True


def _render(template: str, vars: dict[str, Any]) -> str:
    def replace(m: re.Match) -> str:
        key = m.group(1)
        val = vars.get(key)
        if val is None:
            return m.group(0)
        if isinstance(val, float):
            return f"{val:.1f}"
        return str(val)
    return _VAR_RE.sub(replace, template)


def generate_insights(user_id: str, target_date: date) -> list[dict]:
    """
    Evaluate all templates, render top 1–3, write to user_insights, return list.
    """
    db = get_db()
    window_start = target_date - timedelta(days=6)

    # --- Fetch wearable summary for target date ---
    wearable_resp = (
        db.table("wearable_daily_summary")
        .select("*")
        .eq("user_id", user_id)
        .eq("date", target_date.isoformat())
        .limit(1)
        .execute()
    )
    wearable: dict = wearable_resp.data[0] if wearable_resp.data else {}

    # --- Fetch user_daily_tags for last 7 days ---
    tags_resp = (
        db.table("user_daily_tags")
        .select("date, source, tags(name)")
        .eq("user_id", user_id)
        .gte("date", window_start.isoformat())
        .lte("date", target_date.isoformat())
        .execute()
    )
    tag_rows = tags_resp.data or []

    # All tags across the window (deduped set of names)
    all_tag_names: set[str] = set()
    tags_by_date: dict[str, set[str]] = defaultdict(set)
    for row in tag_rows:
        name = row.get("tags", {}).get("name") if isinstance(row.get("tags"), dict) else None
        if name:
            all_tag_names.add(name)
            tags_by_date[row["date"]].add(name)

    # Include cycle_phase as a pseudo-tag
    if wearable.get("cycle_phase"):
        phase = wearable["cycle_phase"] + "_phase"  # e.g. 'luteal_phase'
        all_tag_names.add(phase)
        tags_by_date[target_date.isoformat()].add(phase)

    # --- Fetch last 3 days of user_insights to dedupe ---
    recent_resp = (
        db.table("user_insights")
        .select("template_id")
        .eq("user_id", user_id)
        .gte("date", (target_date - timedelta(days=3)).isoformat())
        .lt("date", target_date.isoformat())
        .execute()
    )
    recent_template_ids: set[str] = {
        r["template_id"] for r in (recent_resp.data or []) if r.get("template_id")
    }

    # --- Evaluate templates ---
    templates_resp = db.table("insight_templates").select("*").order("priority").execute()
    templates = templates_resp.data or []

    matched: list[dict] = []
    for tmpl in templates:
        if tmpl["id"] in recent_template_ids:
            continue

        cond: dict = tmpl.get("trigger_conditions") or {}
        required_tags: list[str] = cond.get("require_tags", [])
        any_tags: list[str] = cond.get("require_any_tags", [])
        wearable_cond: dict = cond.get("require_wearable", {})
        min_days: int = cond.get("min_days_of_signal", 1)

        # Check required tags
        if not all(t in all_tag_names for t in required_tags):
            continue

        # Check require_any_tags (at least one must match)
        if any_tags and not any(t in all_tag_names for t in any_tags):
            continue

        # Check wearable conditions
        wearable_ok = True
        for field, field_cond in wearable_cond.items():
            if not _eval_numeric_condition(wearable.get(field), field_cond):
                wearable_ok = False
                break
        if not wearable_ok:
            continue

        # Check min_days_of_signal (any required tag must appear on min_days distinct dates)
        if min_days > 1 and required_tags:
            tag_to_check = required_tags[0]
            days_with_tag = sum(
                1 for tags in tags_by_date.values() if tag_to_check in tags
            )
            if days_with_tag < min_days:
                continue

        # Render template variables
        hrv_drop = abs(round(wearable.get("hrv_vs_personal_baseline", 0), 1))
        days_with_first_required = 1
        if required_tags:
            days_with_first_required = sum(
                1 for tags in tags_by_date.values() if required_tags[0] in tags
            )

        rendered = _render(tmpl["message_template"], {
            "hrv_drop": hrv_drop,
            "n": days_with_first_required,
        })

        matched.append({
            "template": tmpl,
            "rendered": rendered,
        })

        if len(matched) >= 3:
            break

    if not matched:
        return []

    # --- Write to user_insights ---
    insert_rows = [
        {
            "user_id": user_id,
            "date": target_date.isoformat(),
            "template_id": m["template"]["id"],
            "message_rendered": m["rendered"],
            "study_ids": m["template"].get("study_ids") or [],
            "dismissed": False,
        }
        for m in matched
    ]
    written = db.table("user_insights").upsert(insert_rows).execute()
    written_rows = written.data or []

    return [
        {
            "id": w["id"],
            "date": w["date"],
            "message": w["message_rendered"],
            "category": m["template"]["category"],
            "priority": m["template"]["priority"],
            "study_ids": w.get("study_ids") or [],
            "dismissed": w.get("dismissed", False),
        }
        for w, m in zip(written_rows, matched)
    ]

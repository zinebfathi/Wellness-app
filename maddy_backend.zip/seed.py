"""
Run this once to:
1. Create all tables in Supabase
2. Seed the tags table
3. Seed wearable_daily_summary from existing oura_* tables (for Maya Chen, user_id stub)
4. Create the daily_prompt_dismissals table

Usage: python3 seed.py
"""

import os
import sys
from datetime import date, timedelta

from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY") or os.environ["SUPABASE_KEY"]
DEMO_USER_ID = "00000000-0000-0000-0000-000000000001"

db = create_client(SUPABASE_URL, SUPABASE_KEY)


# ── DDL via rpc or direct table ops (Supabase Python client can't run raw SQL) ──
# We use the REST API upsert pattern — tables must be created in Supabase SQL editor.
# Print the SQL files so user can run them if tables don't exist.

DDL_DIR = os.path.join(os.path.dirname(__file__), "sql")


def print_ddl_reminder():
    print("\n" + "=" * 60)
    print("IMPORTANT: Run the following SQL files in the Supabase SQL editor")
    print("if the tables don't already exist:")
    for fname in sorted(os.listdir(DDL_DIR)):
        if fname.endswith(".sql"):
            print(f"  → {os.path.join(DDL_DIR, fname)}")
    print("=" * 60 + "\n")


def seed_tags():
    print("Seeding tags...")
    # Tags are seeded via SQL file. Verify by checking count.
    resp = db.table("tags").select("id", count="exact").execute()
    count = resp.count or 0
    print(f"  tags table has {count} rows.")
    if count == 0:
        print("  ⚠️  Tags table is empty — run sql/001_tags.sql in Supabase SQL editor first.")
    else:
        print("  ✓ Tags already seeded.")


def seed_wearable_summary():
    print("Seeding wearable_daily_summary from Oura data...")

    # Fetch all readiness rows (has score + hrv + temp)
    readiness = db.table("oura_readiness").select("*").order("summary_date").execute().data or []
    # Fetch daily sleep for sleep_score, sleep_duration
    daily_sleep = {
        r["day"]: r
        for r in (db.table("oura_daily_sleep").select("*").execute().data or [])
    }
    # Fetch daily activity for steps, active_minutes
    daily_activity = {
        r["day"]: r
        for r in (db.table("oura_daily_activity").select("*").execute().data or [])
    }
    # Fetch sleep for hrv and resting_hr
    sleep = {
        r["day"]: r
        for r in (db.table("oura_sleep").select("*").execute().data or [])
    }

    # Compute 30-day rolling baseline for HRV and resting HR
    # We'll do a simple pass: use cycle_day from readiness to infer phase
    CYCLE_LENGTH = 28
    MENSTRUAL_DAYS = range(1, 6)       # days 1-5
    FOLLICULAR_DAYS = range(6, 14)     # days 6-13
    OVULATORY_DAYS = range(14, 17)     # days 14-16
    LUTEAL_DAYS = range(17, 29)        # days 17-28

    def infer_phase(cycle_day: int | None) -> str | None:
        if cycle_day is None:
            return None
        cd = ((cycle_day - 1) % CYCLE_LENGTH) + 1
        if cd in MENSTRUAL_DAYS:
            return "menstrual"
        if cd in FOLLICULAR_DAYS:
            return "follicular"
        if cd in OVULATORY_DAYS:
            return "ovulatory"
        if cd in LUTEAL_DAYS:
            return "luteal"
        return None

    # Compute global averages for baseline deviation
    hrv_values = [s["average_hrv"] for s in sleep.values() if s.get("average_hrv")]
    hr_values = [s["lowest_heart_rate"] for s in sleep.values() if s.get("lowest_heart_rate")]
    hrv_baseline = sum(hrv_values) / len(hrv_values) if hrv_values else 50.0
    hr_baseline = sum(hr_values) / len(hr_values) if hr_values else 55.0

    rows = []
    for r in readiness:
        d = r["summary_date"]
        sl = sleep.get(d, {})
        ds = daily_sleep.get(d, {})
        da = daily_activity.get(d, {})

        hrv = sl.get("average_hrv")
        rhr = sl.get("lowest_heart_rate")
        hrv_dev = round((hrv - hrv_baseline) / hrv_baseline * 100, 1) if hrv else None
        rhr_dev = round((rhr - hr_baseline) / hr_baseline * 100, 1) if rhr else None

        sleep_dur_min = sl.get("total_sleep_duration")
        if sleep_dur_min:
            sleep_dur_min = sleep_dur_min // 60  # seconds → minutes

        rows.append({
            "user_id": DEMO_USER_ID,
            "date": d,
            "hrv_rmssd": hrv,
            "hrv_vs_personal_baseline": hrv_dev,
            "resting_hr": rhr,
            "resting_hr_vs_baseline": rhr_dev,
            "skin_temp_deviation": r.get("temperature_deviation"),
            "sleep_score": ds.get("score"),
            "sleep_duration_minutes": sleep_dur_min,
            "sleep_efficiency": sl.get("efficiency") / 100.0 if sl.get("efficiency") else None,
            "readiness_score": r.get("score"),
            "steps": da.get("steps"),
            "active_minutes": (
                (da.get("high_activity_time", 0) or 0) + (da.get("medium_activity_time", 0) or 0)
            ) // 60 if da else None,
            "cycle_phase": infer_phase(r.get("cycle_day")),
            "cycle_phase_source": "predicted",
            "source_device": "oura",
        })

    # Batch upsert
    BATCH = 100
    total = 0
    for i in range(0, len(rows), BATCH):
        db.table("wearable_daily_summary").upsert(
            rows[i:i+BATCH], on_conflict="user_id,date"
        ).execute()
        total += len(rows[i:i+BATCH])
        print(f"  wearable_daily_summary: {total}/{len(rows)}", end="\r", flush=True)
    print(f"  ✓ wearable_daily_summary: {len(rows)} rows upserted.")


def create_dismissals_table_reminder():
    print("\nAlso run this SQL to create the daily_prompt_dismissals table:")
    print("""
  CREATE TABLE IF NOT EXISTS daily_prompt_dismissals (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    date       DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(user_id, date)
  );
""")


if __name__ == "__main__":
    print_ddl_reminder()
    seed_tags()
    seed_wearable_summary()
    create_dismissals_table_reminder()
    print("\nSeed complete.")

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routes.auto_tagger import router as auto_tagger_router
from routes.daily_prompt import router as daily_prompt_router
from routes.insights import router as insights_router
from routes.tags import router as tags_router
from routes.tags import user_tags_router

app = FastAPI(title="Women's Health API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(tags_router)
app.include_router(user_tags_router)
app.include_router(insights_router)
app.include_router(daily_prompt_router)
app.include_router(auto_tagger_router)


@app.get("/health")
def health():
    return {"status": "ok"}

-- Step 5: wearable_daily_summary table

CREATE TABLE IF NOT EXISTS wearable_daily_summary (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                   UUID NOT NULL,
  date                      DATE NOT NULL,
  hrv_rmssd                 FLOAT,
  hrv_vs_personal_baseline  FLOAT,
  resting_hr                INT,
  resting_hr_vs_baseline    FLOAT,
  skin_temp_deviation       FLOAT,
  sleep_score               INT,
  sleep_duration_minutes    INT,
  sleep_efficiency          FLOAT,
  readiness_score           INT,
  steps                     INT,
  active_minutes            INT,
  cycle_phase               TEXT,         -- 'menstrual' | 'follicular' | 'ovulatory' | 'luteal' | null
  cycle_phase_source        TEXT,         -- 'user_logged' | 'temp_inferred' | 'predicted'
  source_device             TEXT,         -- 'oura' | 'whoop' | 'apple_watch' | 'fitbit'
  created_at                TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, date)
);

CREATE INDEX IF NOT EXISTS idx_wearable_summary_user_date ON wearable_daily_summary(user_id, date);

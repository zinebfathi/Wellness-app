-- Step 1: Tags table + seed data
-- Run in Supabase SQL editor

CREATE TABLE IF NOT EXISTS tags (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  category    TEXT NOT NULL,
  source      TEXT NOT NULL,   -- 'calendar' | 'user' | 'computed'
  description TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
);

-- Calendar-derived tags
INSERT INTO tags (name, label, category, source) VALUES
  ('working_late',           'Working Late',           'work_schedule', 'calendar'),
  ('early_morning',          'Early Morning',          'work_schedule', 'calendar'),
  ('back_to_back_meetings',  'Back-to-Back Meetings',  'work_schedule', 'calendar'),
  ('long_workday',           'Long Workday',           'work_schedule', 'calendar'),
  ('weekend_work',           'Weekend Work',           'work_schedule', 'calendar'),
  ('traveling',              'Traveling',              'travel',        'calendar'),
  ('long_haul_travel',       'Long-Haul Travel',       'travel',        'calendar'),
  ('travel_recovery',        'Travel Recovery Day',    'travel',        'calendar'),
  ('early_flight',           'Early Flight',           'travel',        'calendar'),
  ('red_eye',                'Red-Eye Flight',         'travel',        'calendar'),
  ('social_event',           'Social Event',           'social',        'calendar'),
  ('late_night',             'Late Night',             'social',        'calendar'),
  ('rest_day_scheduled',     'Rest Day',               'recovery',      'calendar'),
  ('doctor_appointment',     'Doctor Appointment',     'health',        'calendar'),
  ('sick_day',               'Sick Day',               'health',        'calendar'),
  ('vacation',               'Vacation',               'travel',        'calendar')
ON CONFLICT (name) DO NOTHING;

-- Computed tags
INSERT INTO tags (name, label, category, source) VALUES
  ('high_stress_week',   'High Stress Week',    'computed', 'computed'),
  ('disrupted_schedule', 'Disrupted Schedule',  'computed', 'computed')
ON CONFLICT (name) DO NOTHING;

-- User tags: workout_feeling
INSERT INTO tags (name, label, category, source) VALUES
  ('felt_strong',        'Felt Strong',           'workout_feeling', 'user'),
  ('felt_sluggish',      'Felt Sluggish',         'workout_feeling', 'user'),
  ('low_motivation',     'Low Motivation',        'workout_feeling', 'user'),
  ('hit_a_new_pr',       'Hit a New PR',          'workout_feeling', 'user'),
  ('cut_workout_short',  'Cut Workout Short',     'workout_feeling', 'user'),
  ('skipped_workout',    'Skipped Workout',       'workout_feeling', 'user'),
  ('sore_from_yesterday','Sore from Yesterday',   'workout_feeling', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: energy_mood
INSERT INTO tags (name, label, category, source) VALUES
  ('high_energy',  'High Energy',   'energy_mood', 'user'),
  ('low_energy',   'Low Energy',    'energy_mood', 'user'),
  ('brain_fog',    'Brain Fog',     'energy_mood', 'user'),
  ('anxious',      'Anxious',       'energy_mood', 'user'),
  ('calm',         'Calm',          'energy_mood', 'user'),
  ('mood_swings',  'Mood Swings',   'energy_mood', 'user'),
  ('irritable',    'Irritable',     'energy_mood', 'user'),
  ('bloated',      'Bloated',       'energy_mood', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: sleep_quality
INSERT INTO tags (name, label, category, source) VALUES
  ('slept_well',              'Slept Well',              'sleep_quality', 'user'),
  ('poor_sleep',              'Poor Sleep',              'sleep_quality', 'user'),
  ('woke_up_multiple_times',  'Woke Up Multiple Times',  'sleep_quality', 'user'),
  ('slept_too_little',        'Too Little Sleep',         'sleep_quality', 'user'),
  ('napped',                  'Napped',                  'sleep_quality', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: cycle_symptoms
INSERT INTO tags (name, label, category, source) VALUES
  ('cramps',           'Cramps',                   'cycle_symptoms', 'user'),
  ('spotting',         'Spotting',                 'cycle_symptoms', 'user'),
  ('headache',         'Headache',                 'cycle_symptoms', 'user'),
  ('breast_tenderness','Breast Tenderness',         'cycle_symptoms', 'user'),
  ('heavy_flow',       'Heavy Flow',               'cycle_symptoms', 'user'),
  ('light_flow',       'Light Flow',               'cycle_symptoms', 'user'),
  ('water_retention',  'Water Retention',           'cycle_symptoms', 'user'),
  ('lower_back_pain',  'Lower Back Pain',           'cycle_symptoms', 'user'),
  ('food_cravings',    'Food Cravings',             'cycle_symptoms', 'user'),
  ('insomnia_cycle',   'Cycle-Related Insomnia',    'cycle_symptoms', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: nutrition_lifestyle
INSERT INTO tags (name, label, category, source) VALUES
  ('ate_well',       'Ate Well',         'nutrition_lifestyle', 'user'),
  ('poor_nutrition', 'Poor Nutrition',   'nutrition_lifestyle', 'user'),
  ('drank_alcohol',  'Drank Alcohol',    'nutrition_lifestyle', 'user'),
  ('high_caffeine',  'High Caffeine',    'nutrition_lifestyle', 'user'),
  ('forgot_to_eat',  'Forgot to Eat',    'nutrition_lifestyle', 'user'),
  ('hydrated',       'Well Hydrated',    'nutrition_lifestyle', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: travel_disruption
INSERT INTO tags (name, label, category, source) VALUES
  ('jet_lagged',            'Jet Lagged',          'travel_disruption', 'user'),
  ('off_routine',           'Off Routine',         'travel_disruption', 'user'),
  ('new_environment',       'New Environment',     'travel_disruption', 'user'),
  ('stressed_about_travel', 'Stressed About Travel','travel_disruption', 'user')
ON CONFLICT (name) DO NOTHING;
-- Step 2: user_daily_tags table

CREATE TABLE IF NOT EXISTS user_daily_tags (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  date       DATE NOT NULL,
  tag_id     UUID NOT NULL REFERENCES tags(id),
  source     TEXT NOT NULL,   -- 'calendar' | 'user' | 'computed'
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, date, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_user_daily_tags_user_date ON user_daily_tags(user_id, date);
-- Step 5: wearable_daily_summary table

CREATE TABLE IF NOT EXISTS wearable_daily_summary (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                   UUID NOT NULL,
  date                      DATE NOT NULL,
  hrv_rmssd                 FLOAT,
  hrv_vs_personal_baseline  FLOAT,
  resting_hr                INT,
  resting_hr_vs_baseline    FLOAT,
  skin_temp_deviation       FLOAT,
  sleep_score               INT,
  sleep_duration_minutes    INT,
  sleep_efficiency          FLOAT,
  readiness_score           INT,
  steps                     INT,
  active_minutes            INT,
  cycle_phase               TEXT,         -- 'menstrual' | 'follicular' | 'ovulatory' | 'luteal' | null
  cycle_phase_source        TEXT,         -- 'user_logged' | 'temp_inferred' | 'predicted'
  source_device             TEXT,         -- 'oura' | 'whoop' | 'apple_watch' | 'fitbit'
  created_at                TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, date)
);

CREATE INDEX IF NOT EXISTS idx_wearable_summary_user_date ON wearable_daily_summary(user_id, date);
-- Step 6: insight_templates and user_insights tables

CREATE TABLE IF NOT EXISTS insight_templates (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_conditions  JSONB NOT NULL,
  message_template    TEXT NOT NULL,
  category            TEXT NOT NULL,   -- 'recovery' | 'performance' | 'cycle' | 'travel' | 'nutrition'
  priority            INT DEFAULT 5,   -- 1 = highest
  study_ids           TEXT[],
  created_at          TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_insights (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL,
  date             DATE NOT NULL,
  template_id      UUID REFERENCES insight_templates(id),
  message_rendered TEXT NOT NULL,
  study_ids        TEXT[],
  dismissed        BOOLEAN DEFAULT false,
  dismissed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_insights_user_date ON user_insights(user_id, date);

-- Seed the 12 MVP insight templates
INSERT INTO insight_templates (trigger_conditions, message_template, category, priority, study_ids) VALUES

(
  '{"require_tags": ["luteal_phase"], "require_wearable": {"hrv_vs_personal_baseline": {"lt": -10}}, "min_days_of_signal": 2}',
  'Your HRV has been {{hrv_drop}}% below your personal baseline for {{n}} days. This is common in the luteal phase — your body isn''t underrecovering, it''s doing hormonal work. Consider keeping intensity moderate today.',
  'cycle', 1, ARRAY['20', '21']
),

(
  '{"require_tags": ["traveling"], "require_wearable": {"resting_hr_vs_baseline": {"gt": 5}}}',
  'Your resting HR was elevated overnight after travel. Based on the science, it typically takes 1–2 days to recalibrate after crossing time zones. We''d suggest a lighter session today.',
  'travel', 2, ARRAY['14', '11']
),

(
  '{"require_tags": ["high_stress_week"]}',
  'You''ve had a high-load week on paper — late nights, packed calendar. Even if your workouts felt okay, your body may be carrying more background stress than usual. Prioritize sleep tonight.',
  'recovery', 3, ARRAY['15', '16']
),

(
  '{"require_tags": ["follicular_phase"], "require_wearable": {"hrv_vs_personal_baseline": {"gte": 0}}}',
  'You''re in your follicular phase and your recovery signals look strong. This is typically your highest-performance window — a good week to push progressive overload or test a new PR.',
  'performance', 4, ARRAY['1', '2', '9']
),

(
  '{"require_tags": ["cramps"], "require_wearable": {"readiness_score": {"lt": 65}}}',
  'You tagged cramps today and your readiness score is low. Light movement like walking or yoga tends to be more effective than rest for managing cramp pain — but only if it feels right.',
  'cycle', 5, ARRAY['10']
),

(
  '{"require_tags": ["disrupted_schedule", "poor_sleep"]}',
  'Your schedule has been disrupted and sleep has taken a hit. Disrupted routines are one of the clearest signals of cycle disruption risk. Try to anchor your sleep/wake time for the next 2 days.',
  'recovery', 6, ARRAY['13', '16']
),

(
  '{"require_tags": ["luteal_phase", "food_cravings"]}',
  'Food cravings in the luteal phase are metabolically real — your resting calorie needs increase by roughly 6–7%. A small increase in carbohydrates (especially before workouts) can help performance and mood.',
  'nutrition', 7, ARRAY['26', '27']
),

(
  '{"require_tags": ["ovulatory_phase"], "require_any_tags": ["sore_from_yesterday", "cut_workout_short"]}',
  'You''re near ovulation, when estrogen peaks and ligament laxity increases slightly. It''s worth being intentional about warmup and form today, especially for lateral movements or heavy lifts.',
  'performance', 8, ARRAY['23', '24']
),

(
  '{"require_tags": ["jet_lagged"]}',
  'Travel across time zones can shift your cycle timing by delaying the LH surge. If your period seems late after this trip, that''s a known effect — not a reason to worry.',
  'travel', 9, ARRAY['11', '13']
),

(
  '{"require_tags": ["follicular_phase", "slept_well"], "min_days_of_signal": 3}',
  'You''ve had strong sleep for several nights and you''re in the follicular phase. This is one of the best recovery combinations for adaptation — training load from this week is more likely to stick.',
  'performance', 10, ARRAY['28', '2']
),

(
  '{"require_tags": ["poor_nutrition", "working_late"], "min_days_of_signal": 2}',
  'Late workdays and nutrition tend to drop together. In the follicular phase this matters less, but in the luteal phase under-fueling can amplify fatigue and mood shifts.',
  'nutrition', 11, ARRAY['25', '26']
),

(
  '{"require_tags": ["back_to_back_meetings", "low_energy"]}',
  'A packed meeting schedule creates cognitive load that reads as physical stress. If your workout felt harder than expected today, that''s likely why — not fitness regression.',
  'recovery', 12, ARRAY['15']
);

-- daily_prompt_dismissals table
CREATE TABLE IF NOT EXISTS daily_prompt_dismissals (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  date       DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, date)
);

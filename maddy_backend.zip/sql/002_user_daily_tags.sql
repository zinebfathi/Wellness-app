-- Step 2: user_daily_tags table

CREATE TABLE IF NOT EXISTS user_daily_tags (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  date       DATE NOT NULL,
  tag_id     UUID NOT NULL REFERENCES tags(id),
  source     TEXT NOT NULL,   -- 'calendar' | 'user' | 'computed'
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, date, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_user_daily_tags_user_date ON user_daily_tags(user_id, date);

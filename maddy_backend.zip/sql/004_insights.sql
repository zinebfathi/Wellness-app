-- Step 6: insight_templates and user_insights tables

CREATE TABLE IF NOT EXISTS insight_templates (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_conditions  JSONB NOT NULL,
  message_template    TEXT NOT NULL,
  category            TEXT NOT NULL,   -- 'recovery' | 'performance' | 'cycle' | 'travel' | 'nutrition'
  priority            INT DEFAULT 5,   -- 1 = highest
  study_ids           TEXT[],
  created_at          TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_insights (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL,
  date             DATE NOT NULL,
  template_id      UUID REFERENCES insight_templates(id),
  message_rendered TEXT NOT NULL,
  study_ids        TEXT[],
  dismissed        BOOLEAN DEFAULT false,
  dismissed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_insights_user_date ON user_insights(user_id, date);

-- Seed the 12 MVP insight templates
INSERT INTO insight_templates (trigger_conditions, message_template, category, priority, study_ids) VALUES

(
  '{"require_tags": ["luteal_phase"], "require_wearable": {"hrv_vs_personal_baseline": {"lt": -10}}, "min_days_of_signal": 2}',
  'Your HRV has been {{hrv_drop}}% below your personal baseline for {{n}} days. This is common in the luteal phase — your body isn''t underrecovering, it''s doing hormonal work. Consider keeping intensity moderate today.',
  'cycle', 1, ARRAY['20', '21']
),

(
  '{"require_tags": ["traveling"], "require_wearable": {"resting_hr_vs_baseline": {"gt": 5}}}',
  'Your resting HR was elevated overnight after travel. Based on the science, it typically takes 1–2 days to recalibrate after crossing time zones. We''d suggest a lighter session today.',
  'travel', 2, ARRAY['14', '11']
),

(
  '{"require_tags": ["high_stress_week"]}',
  'You''ve had a high-load week on paper — late nights, packed calendar. Even if your workouts felt okay, your body may be carrying more background stress than usual. Prioritize sleep tonight.',
  'recovery', 3, ARRAY['15', '16']
),

(
  '{"require_tags": ["follicular_phase"], "require_wearable": {"hrv_vs_personal_baseline": {"gte": 0}}}',
  'You''re in your follicular phase and your recovery signals look strong. This is typically your highest-performance window — a good week to push progressive overload or test a new PR.',
  'performance', 4, ARRAY['1', '2', '9']
),

(
  '{"require_tags": ["cramps"], "require_wearable": {"readiness_score": {"lt": 65}}}',
  'You tagged cramps today and your readiness score is low. Light movement like walking or yoga tends to be more effective than rest for managing cramp pain — but only if it feels right.',
  'cycle', 5, ARRAY['10']
),

(
  '{"require_tags": ["disrupted_schedule", "poor_sleep"]}',
  'Your schedule has been disrupted and sleep has taken a hit. Disrupted routines are one of the clearest signals of cycle disruption risk. Try to anchor your sleep/wake time for the next 2 days.',
  'recovery', 6, ARRAY['13', '16']
),

(
  '{"require_tags": ["luteal_phase", "food_cravings"]}',
  'Food cravings in the luteal phase are metabolically real — your resting calorie needs increase by roughly 6–7%. A small increase in carbohydrates (especially before workouts) can help performance and mood.',
  'nutrition', 7, ARRAY['26', '27']
),

(
  '{"require_tags": ["ovulatory_phase"], "require_any_tags": ["sore_from_yesterday", "cut_workout_short"]}',
  'You''re near ovulation, when estrogen peaks and ligament laxity increases slightly. It''s worth being intentional about warmup and form today, especially for lateral movements or heavy lifts.',
  'performance', 8, ARRAY['23', '24']
),

(
  '{"require_tags": ["jet_lagged"]}',
  'Travel across time zones can shift your cycle timing by delaying the LH surge. If your period seems late after this trip, that''s a known effect — not a reason to worry.',
  'travel', 9, ARRAY['11', '13']
),

(
  '{"require_tags": ["follicular_phase", "slept_well"], "min_days_of_signal": 3}',
  'You''ve had strong sleep for several nights and you''re in the follicular phase. This is one of the best recovery combinations for adaptation — training load from this week is more likely to stick.',
  'performance', 10, ARRAY['28', '2']
),

(
  '{"require_tags": ["poor_nutrition", "working_late"], "min_days_of_signal": 2}',
  'Late workdays and nutrition tend to drop together. In the follicular phase this matters less, but in the luteal phase under-fueling can amplify fatigue and mood shifts.',
  'nutrition', 11, ARRAY['25', '26']
),

(
  '{"require_tags": ["back_to_back_meetings", "low_energy"]}',
  'A packed meeting schedule creates cognitive load that reads as physical stress. If your workout felt harder than expected today, that''s likely why — not fitness regression.',
  'recovery', 12, ARRAY['15']
);

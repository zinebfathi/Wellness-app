-- Step 1: Tags table + seed data
-- Run in Supabase SQL editor

CREATE TABLE IF NOT EXISTS tags (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  category    TEXT NOT NULL,
  source      TEXT NOT NULL,   -- 'calendar' | 'user' | 'computed'
  description TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
);

-- Calendar-derived tags
INSERT INTO tags (name, label, category, source) VALUES
  ('working_late',           'Working Late',           'work_schedule', 'calendar'),
  ('early_morning',          'Early Morning',          'work_schedule', 'calendar'),
  ('back_to_back_meetings',  'Back-to-Back Meetings',  'work_schedule', 'calendar'),
  ('long_workday',           'Long Workday',           'work_schedule', 'calendar'),
  ('weekend_work',           'Weekend Work',           'work_schedule', 'calendar'),
  ('traveling',              'Traveling',              'travel',        'calendar'),
  ('long_haul_travel',       'Long-Haul Travel',       'travel',        'calendar'),
  ('travel_recovery',        'Travel Recovery Day',    'travel',        'calendar'),
  ('early_flight',           'Early Flight',           'travel',        'calendar'),
  ('red_eye',                'Red-Eye Flight',         'travel',        'calendar'),
  ('social_event',           'Social Event',           'social',        'calendar'),
  ('late_night',             'Late Night',             'social',        'calendar'),
  ('rest_day_scheduled',     'Rest Day',               'recovery',      'calendar'),
  ('doctor_appointment',     'Doctor Appointment',     'health',        'calendar'),
  ('sick_day',               'Sick Day',               'health',        'calendar'),
  ('vacation',               'Vacation',               'travel',        'calendar')
ON CONFLICT (name) DO NOTHING;

-- Computed tags
INSERT INTO tags (name, label, category, source) VALUES
  ('high_stress_week',   'High Stress Week',    'computed', 'computed'),
  ('disrupted_schedule', 'Disrupted Schedule',  'computed', 'computed')
ON CONFLICT (name) DO NOTHING;

-- User tags: workout_feeling
INSERT INTO tags (name, label, category, source) VALUES
  ('felt_strong',        'Felt Strong',           'workout_feeling', 'user'),
  ('felt_sluggish',      'Felt Sluggish',         'workout_feeling', 'user'),
  ('low_motivation',     'Low Motivation',        'workout_feeling', 'user'),
  ('hit_a_new_pr',       'Hit a New PR',          'workout_feeling', 'user'),
  ('cut_workout_short',  'Cut Workout Short',     'workout_feeling', 'user'),
  ('skipped_workout',    'Skipped Workout',       'workout_feeling', 'user'),
  ('sore_from_yesterday','Sore from Yesterday',   'workout_feeling', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: energy_mood
INSERT INTO tags (name, label, category, source) VALUES
  ('high_energy',  'High Energy',   'energy_mood', 'user'),
  ('low_energy',   'Low Energy',    'energy_mood', 'user'),
  ('brain_fog',    'Brain Fog',     'energy_mood', 'user'),
  ('anxious',      'Anxious',       'energy_mood', 'user'),
  ('calm',         'Calm',          'energy_mood', 'user'),
  ('mood_swings',  'Mood Swings',   'energy_mood', 'user'),
  ('irritable',    'Irritable',     'energy_mood', 'user'),
  ('bloated',      'Bloated',       'energy_mood', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: sleep_quality
INSERT INTO tags (name, label, category, source) VALUES
  ('slept_well',              'Slept Well',              'sleep_quality', 'user'),
  ('poor_sleep',              'Poor Sleep',              'sleep_quality', 'user'),
  ('woke_up_multiple_times',  'Woke Up Multiple Times',  'sleep_quality', 'user'),
  ('slept_too_little',        'Too Little Sleep',         'sleep_quality', 'user'),
  ('napped',                  'Napped',                  'sleep_quality', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: cycle_symptoms
INSERT INTO tags (name, label, category, source) VALUES
  ('cramps',           'Cramps',                   'cycle_symptoms', 'user'),
  ('spotting',         'Spotting',                 'cycle_symptoms', 'user'),
  ('headache',         'Headache',                 'cycle_symptoms', 'user'),
  ('breast_tenderness','Breast Tenderness',         'cycle_symptoms', 'user'),
  ('heavy_flow',       'Heavy Flow',               'cycle_symptoms', 'user'),
  ('light_flow',       'Light Flow',               'cycle_symptoms', 'user'),
  ('water_retention',  'Water Retention',           'cycle_symptoms', 'user'),
  ('lower_back_pain',  'Lower Back Pain',           'cycle_symptoms', 'user'),
  ('food_cravings',    'Food Cravings',             'cycle_symptoms', 'user'),
  ('insomnia_cycle',   'Cycle-Related Insomnia',    'cycle_symptoms', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: nutrition_lifestyle
INSERT INTO tags (name, label, category, source) VALUES
  ('ate_well',       'Ate Well',         'nutrition_lifestyle', 'user'),
  ('poor_nutrition', 'Poor Nutrition',   'nutrition_lifestyle', 'user'),
  ('drank_alcohol',  'Drank Alcohol',    'nutrition_lifestyle', 'user'),
  ('high_caffeine',  'High Caffeine',    'nutrition_lifestyle', 'user'),
  ('forgot_to_eat',  'Forgot to Eat',    'nutrition_lifestyle', 'user'),
  ('hydrated',       'Well Hydrated',    'nutrition_lifestyle', 'user')
ON CONFLICT (name) DO NOTHING;

-- User tags: travel_disruption
INSERT INTO tags (name, label, category, source) VALUES
  ('jet_lagged',            'Jet Lagged',          'travel_disruption', 'user'),
  ('off_routine',           'Off Routine',         'travel_disruption', 'user'),
  ('new_environment',       'New Environment',     'travel_disruption', 'user'),
  ('stressed_about_travel', 'Stressed About Travel','travel_disruption', 'user')
ON CONFLICT (name) DO NOTHING;

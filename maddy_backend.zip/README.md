# Women's Health API — Tags & Insights Backend

## Setup (one-time)

### 1. Create tables in Supabase
Open the **Supabase SQL editor** for project `kyhdrcnaezxugfinxvjy` and run:

```
backend/sql/ALL_MIGRATIONS.sql
```

This creates: `tags`, `user_daily_tags`, `wearable_daily_summary`,
`insight_templates`, `user_insights`, `daily_prompt_dismissals`.

### 2. Seed data

```bash
cd /Users/maddywelch/backend
python3 seed.py
```

Populates `wearable_daily_summary` from the existing Oura tables (Maya Chen data).

### 3. Run the API

```bash
cd /Users/maddywelch/backend
uvicorn main:app --reload --port 8000
```

Interactive docs: http://localhost:8000/docs

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /tags | All tags grouped by category |
| POST | /user-tags | Write user tag selections for a day |
| GET | /user-tags?date= | Tags for a specific day |
| GET | /user-tags?start=&end= | Tag history for a window |
| DELETE | /user-tags/{tag_id}?date= | Remove a user tag |
| POST | /auto-tag | Trigger calendar auto-tagger for a date range |
| POST | /auto-tag/computed | Run computed tag pass for a date |
| GET | /insights/today | 1–3 prioritized insights for today |
| GET | /insights/history | Insights for last 14 days |
| POST | /insights/{id}/dismiss | Dismiss an insight |
| GET | /daily-prompt | Daily popup config (categories + dismissed state) |
| POST | /daily-prompt/dismiss | Dismiss today's prompt |

---

## Project layout

```
backend/
  main.py                      FastAPI app
  db.py                        Supabase client singleton
  seed.py                      One-time seed script
  services/
    calendar_tagger.py         Calendar auto-tag engine (Steps 2 & 4)
    insights_engine.py         Insights evaluator & renderer (Step 6)
    daily_prompt.py            Daily popup category logic (Step 8)
  routes/
    tags.py                    /tags + /user-tags
    insights.py                /insights/*
    daily_prompt.py            /daily-prompt
    auto_tagger.py             /auto-tag
  sql/
    001_tags.sql               Tags table + full seed
    002_user_daily_tags.sql    user_daily_tags table
    003_wearable_daily_summary.sql
    004_insights.sql           insight_templates + 12 MVP seeds + user_insights
    ALL_MIGRATIONS.sql         Combined (run this in SQL editor)
```

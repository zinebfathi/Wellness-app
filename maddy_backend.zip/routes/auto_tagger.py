from datetime import date

from fastapi import APIRouter
from pydantic import BaseModel

from services.calendar_tagger import run_auto_tagger, run_computed_tags

router = APIRouter(prefix="/auto-tag", tags=["auto-tagger"])

DEFAULT_USER = "00000000-0000-0000-0000-000000000001"


class AutoTagBody(BaseModel):
    start: date
    end: date
    user_id: str = DEFAULT_USER


@router.post("")
def trigger_auto_tag(body: AutoTagBody):
    """Manually trigger the calendar auto-tagger for a date range."""
    results = run_auto_tagger(body.user_id, body.start, body.end)
    return {"user_id": body.user_id, "tagged_days": results}


@router.post("/computed")
def trigger_computed_tags(anchor_date: date = None, user_id: str = DEFAULT_USER):
    if anchor_date is None:
        anchor_date = date.today()
    fired = run_computed_tags(user_id, anchor_date)
    return {"date": anchor_date.isoformat(), "computed_tags": fired}

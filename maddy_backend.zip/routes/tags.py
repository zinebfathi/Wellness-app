from collections import defaultdict
from datetime import date
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from db import get_db

router = APIRouter(prefix="/tags", tags=["tags"])


@router.get("")
def list_tags():
    """Return all tags grouped by category."""
    db = get_db()
    rows = db.table("tags").select("*").order("category").order("label").execute().data or []
    grouped: dict[str, list] = defaultdict(list)
    for r in rows:
        grouped[r["category"]].append(r)
    return grouped


# ── user-tags ──────────────────────────────────────────────────────────────────

user_tags_router = APIRouter(prefix="/user-tags", tags=["user-tags"])


class TagWriteBody(BaseModel):
    date: date
    tag_ids: list[str]


@user_tags_router.post("")
def write_user_tags(body: TagWriteBody, user_id: str = "00000000-0000-0000-0000-000000000001"):
    db = get_db()
    # Validate tag ids exist and are user-source
    valid_resp = (
        db.table("tags")
        .select("id")
        .in_("id", body.tag_ids)
        .eq("source", "user")
        .execute()
    )
    valid_ids = {r["id"] for r in (valid_resp.data or [])}
    invalid = [tid for tid in body.tag_ids if tid not in valid_ids]
    if invalid:
        raise HTTPException(400, f"Invalid or non-user tag ids: {invalid}")

    rows = [
        {"user_id": user_id, "date": body.date.isoformat(), "tag_id": tid, "source": "user"}
        for tid in body.tag_ids
    ]
    db.table("user_daily_tags").upsert(rows, on_conflict="user_id,date,tag_id").execute()
    return {"written": len(rows)}


@user_tags_router.get("")
def get_user_tags(
    date: Optional[str] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    user_id: str = "00000000-0000-0000-0000-000000000001",
):
    db = get_db()
    query = (
        db.table("user_daily_tags")
        .select("id, date, source, tags(id, name, label, category)")
        .eq("user_id", user_id)
    )
    if date:
        query = query.eq("date", date)
    elif start and end:
        query = query.gte("date", start).lte("date", end)
    else:
        raise HTTPException(400, "Provide either ?date= or ?start=&end=")

    rows = query.order("date").execute().data or []
    return rows


@user_tags_router.delete("/{tag_id}")
def delete_user_tag(
    tag_id: str,
    date: str,
    user_id: str = "00000000-0000-0000-0000-000000000001",
):
    db = get_db()
    db.table("user_daily_tags").delete().match(
        {"user_id": user_id, "date": date, "tag_id": tag_id}
    ).execute()
    return {"deleted": True}

from datetime import date, timedelta

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from db import get_db
from services.insights_engine import generate_insights

router = APIRouter(prefix="/insights", tags=["insights"])

DEFAULT_USER = "00000000-0000-0000-0000-000000000001"


@router.get("/today")
def insights_today(user_id: str = DEFAULT_USER):
    today = date.today()
    insights = generate_insights(user_id, today)
    return {"date": today.isoformat(), "insights": insights}


@router.get("/history")
def insights_history(user_id: str = DEFAULT_USER):
    db = get_db()
    since = (date.today() - timedelta(days=14)).isoformat()
    rows = (
        db.table("user_insights")
        .select("*")
        .eq("user_id", user_id)
        .gte("date", since)
        .order("date", desc=True)
        .execute()
        .data or []
    )
    return rows


@router.post("/{insight_id}/dismiss")
def dismiss_insight(insight_id: str, user_id: str = DEFAULT_USER):
    db = get_db()
    resp = (
        db.table("user_insights")
        .select("id, user_id")
        .eq("id", insight_id)
        .limit(1)
        .execute()
    )
    if not resp.data:
        raise HTTPException(404, "Insight not found")
    if resp.data[0]["user_id"] != user_id:
        raise HTTPException(403, "Forbidden")

    from datetime import datetime
    db.table("user_insights").update(
        {"dismissed": True, "dismissed_at": datetime.utcnow().isoformat()}
    ).eq("id", insight_id).execute()
    return {"dismissed": True}

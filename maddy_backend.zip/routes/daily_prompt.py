from datetime import date

from fastapi import APIRouter

from services.daily_prompt import (
    dismiss_today,
    get_daily_prompt_categories,
    has_dismissed_today,
)

router = APIRouter(prefix="/daily-prompt", tags=["daily-prompt"])

DEFAULT_USER = "00000000-0000-0000-0000-000000000001"


@router.get("")
def daily_prompt(user_id: str = DEFAULT_USER):
    today = date.today()
    dismissed = has_dismissed_today(user_id, today)
    if dismissed:
        return {"show_popup": False, "tag_categories": [], "dismissed": True}

    categories = get_daily_prompt_categories(user_id, today)
    return {
        "show_popup": True,
        "tag_categories": categories,
        "dismissed": False,
    }


@router.post("/dismiss")
def dismiss_prompt(user_id: str = DEFAULT_USER):
    today = date.today()
    dismiss_today(user_id, today)
    return {"dismissed": True}
